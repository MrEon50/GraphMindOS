from core.intent.compiler import IntentCompiler
from core.storage.hybrid_store import HybridStore
from core.engine.router import RoutingEngine
from core.engine.primitives import PrimitiveRegistry
import os

def test_web_capability():
    print("=== GraphMindOS: Internet Capability Test ===")
    
    # Inicjalizacja "Mózgu"
    store = HybridStore()
    engine = RoutingEngine(store)
    
    # Użycie lokalnej Ollamy do transkrypcji naszej testowej Intencji
    compiler = IntentCompiler(model_name="qwen3.5:9b")
    
    # Intencja testowa zlecająca przeczytanie strony 
    intent_command = "Rozpocznij proces. Pobierz tekst ze strony 'http://example.com' wywolujac atom fetch_webpage. Nastepnie po zakonczeniu wywolaj atom log_message zapisujac to jako stan."
    
    # 1. Tłumaczenie do Graph Mind OS DAG
    nodes = compiler.compile_intent(intent_command)
    
    start_node_id = None
    for node in nodes:
        store.add_node(node)
        if node.kind == "intent":
            start_node_id = node.nodeId
            
    if not start_node_id:
        if len(nodes) > 0:
            start_node_id = nodes[0].nodeId
        else:
            print("[TEST] Brak węzła z intencją! LLM Timeout/Parse Error?")
            return
            
    # 2. Bezpieczny, Ewolucyjny spacer po "Graph Web Browserze"
    print("\n--- Uruchomiono Egzkeutor Systemowy ---")
    engine.execute_node(start_node_id)
    
    # 3. Widok z zassanej wiedzy z sieci (Która dodatkowo w HybridStore poszła do ChromaDB jako wektory!)
    print("\n--- Odzyskana wiedza RAG po odczycie strony ---")
    for n_id, n in store._nodes.items():
        if n.kind == "state" or (n.execution and "text_content" in n.execution.payload):
            # Wyswietlamy tylko krotki fragment zebu nie zasmiecac konsoli
            content = n.execution.payload.get("text_content", "")
            print(f"[{n_id}] Fragment wiedzy (Net): '{content[:100]}...'")

if __name__ == "__main__":
    test_web_capability()
