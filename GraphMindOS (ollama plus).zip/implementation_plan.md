# GraphMindOS: System Architecture Blueprint (v2.0 - Memory & Security)

## Goal Description

Projekt ten definiuje ulepszoną architekturę systemu **GraphMindOS**, wzbogaconą o "Prawą Półkulę" (Graph RAG) opartą na lokalnych modelach embedujących (np. `mxbai-embed-large`) oraz wbudowanej wektorowej bazie danych **ChromaDB**. 

Kluczowym celem tej aktualizacji jest wprowadzenie **absolutnego bezpieczeństwa** pracy agenta na lokalnym systemie plików użytkownika. System ma być użyteczny, potrafić czytać i analizować pliki, ale jednocześnie mieć surowy zakaz wykonywania jakichkolwiek działań destrukcyjnych (usuwanie, nadpisywanie ważnych danych) bez wyraźnej i świadomej zgody człowieka (tzw. mechanizm Human-in-the-loop).

## User Review Required

> [!IMPORTANT]
> Proszę o weryfikację sekcji "Mechanizmy Bezpieczeństwa (The Harness)". Czy zaproponowany mechanizm `[Oczekuje na akceptację Użytkownika]` dla modyfikacji plików jest wystarczający? Zastosujemy go w Atomach wykonawczych.

## Proposed Changes

### 1. Pamięć Wektorowa i Kontekstowa (Graph RAG)
Wprowadzamy ChromaDB jako rzeczywisty silnik wektorowy pod maską naszego [HybridStore](file:///c:/Users/Endorfinka/Desktop/ZBIERACZ%20KODU/GraphMindOS/core/storage/hybrid_store.py#6-103).
#### [MODIFY] [core/storage/hybrid_store.py](file:///c:/Users/Endorfinka/Desktop/ZBIERACZ%20KODU/GraphMindOS/core/storage/hybrid_store.py)
- Zastąpienie symulowanej pamięci słownikowej (`dict`) prawdziwym klientem ChromaDB tam, gdzie węzły nie są ulotne i posiadają zawartość semantyczną (wektory).
- Dodanie API do odpytywania modelu Ollama o embedding tekstu przed zapisaniem Węzła typu `state`.

### 2. Atomy Sensoryczne (Pliki i Foldery)
Dodamy nowe węzły operacyjne (Primitives), które na razie pozwolą systemowi **tylko czytać** system.
#### [MODIFY] [core/engine/primitives.py](file:///c:/Users/Endorfinka/Desktop/ZBIERACZ%20KODU/GraphMindOS/core/engine/primitives.py)
- Dodanie Atoma: `@register("read_directory")` (zabezpieczonego CHROOT-em).
- Dodanie Atoma: `@register("read_file")`.
- Dodanie Atoma: `@register("ask_user_permission")` - specjalny węzeł, który przerywa wykonanie grafu i czeka na wejście Y/N z terminala, jeśli kolejny w kolejce jest węzeł modyfikujący.

### 3. Autonomiczna Fabryka Narzędzi (Self-Evolving Primitives)
Stworzenie Mechanizmu, dzięki któremu AI może pisać własne narzędzia (wtyczki) i wszczepiać je do GraphMindOS w czasie rzeczywistym.
#### [MODIFY] [core/engine/primitives.py](file:///c:/Users/Endorfinka/Desktop/ZBIERACZ%20KODU/GraphMindOS/core/engine/primitives.py)
- Dodanie `DynamicPrimitiveLoader` – mechanizmu (np. przez `importlib`), który na gorąco potrafi wczytać nowy moduł Pythona ze wskazanego folderu (np. `workspace/dynamic_atoms/`) i wstrzyknąć nowe funkcje do [PrimitiveRegistry](file:///c:/Users/Endorfinka/Desktop/ZBIERACZ%20KODU/GraphMindOS/core/engine/primitives.py#9-36) be konieczności restartu OS-u.
#### [NEW] `core/evolution/tool_designer.py`
- Nowa pod-jednostka architektoniczna korzystająca z lokalnego LLM. Na żądanie *"Stwórz Atom, który..."* LLM generuje czysty kod w Pythonie, dekoruje go, i zwraca tekst kodu.
- Odbywa się bezkontaktowa kontrola Sanity-Check (czy w kodzie nie ma `os.system('del')`, itp) przez model Judge.
#### [MODIFY] [main.py](file:///c:/Users/Endorfinka/Desktop/ZBIERACZ%20KODU/GraphMindOS/main.py)
- Mechanizm "Fabryki": Kiedy Intent Compiler zgłasza błąd "Brak zarejestrowanego procesora do zadania opisanego przez użytkownika", OS zapyta Terminal: `[AI ARCHITECT] Żądasz operacji, do której nie mam narzędzia. Czy chcesz abym zakodował sobie nowy Atom i podpiął go do systemu? (Y/N)`. Po wciśnięciu 'Y' wyzwolony zostaje `tool_designer`.

### 3. Mechanizmy Bezpieczeństwa (The Harness)
To serce kontroli nad modelem:
- **Chroot (Sandbox):** Zdefiniujemy folder bazowy (np. `C:\Users\Endorfinka\Desktop\ZBIERACZ KODU\GraphMindOS\Workspace`). Atom `read_directory` odrzuci (wyrzuci błąd) każdą próbę wyjścia wyżej (np. `..\..\Windows`).
- **Human-in-the-Loop:** Atomy wykonujące zmiany strukturalne na dysku (np. usuwanie) będą miały wymuszoną relację z węzłem autoryzacji. Intent Compiler zostanie poinstruowany w System Prompcie: *"Jeśli musisz stworzyć węzeł niszczący, MUSISZ poprzedzić go węzłem autoryzacyjnym człowieka"*. W przeciwnym razie Routing Engine wyrzuci wyjątek bezpieczeństwa.
- **Fail-Safe Mutatora:** Jeśli Mutator spróbuje obejść zabezpieczenie katalogu, Judge od razu odrzuci taką łatkę w fazie testowej.
- **Panic Button:** W `main.py` podepniemy przechwycenie `Ctrl+C` (KeyboardInterrupt), które natychmiast zatrzyma spacer po Grafie (Halt Routing).

## Verification Plan

### Automated Tests
- Uruchomienie `test_run.py` symulującego atak agenta na pliki poza dozwolonym Sandboxem (chroot). Skrypt musi zwrócić błąd i zablokować akcję.

### Manual Verification
- Użytkownik zostanie poproszony w terminalu (`main.py`) o wymuszenie na systemie usunięcia pliku testowego. Oczekujemy, że OS wstrzyma wykonywanie DAG, wyświetli monit "Potwierdź usunięcie (Y/N)" i dopiero po akceptacji przepuści sygnał do kolejnego węzła grafu.
