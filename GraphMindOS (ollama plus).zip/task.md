# GraphMindOS Development Plan

## 1. Architektura Koncepcyjna (Macro-Architecture)
- [x] Zdefiniowanie warstw systemu (Storage, Routing, Intent, Execution)
- [x] Projekt hybrydowej bazy danych (Graph + Vector) - Wersja symulowana

## 2. Model Danych (Data Schema)
- [x] Stworzenie struktury węzła (Meta-Schema: UUID, Wektory, Topologia, Entropy)
- [x] Mapowanie relacji przyczynowo-skutkowych dla systemu typu DAG

## 3. Silnik Intencji (Intent-API i Cykl Życia)
- [x] Zaprojektowanie Intent Compilera (Tłumacz języka naturalnego na sub-graf przez Ollama)
- [x] Integracja Menu Terminalowego (Ollama Models)

## 4. Logika i Wykonanie (Execution Layer)
- [x] System dynamicznych wag i routingu w DAG
- [x] Definicja Atomów Wykonawczych i Bezpiecznego AST (Registry + SafeEvaluator)
- [x] Zabezpieczenie Atomów (Human-in-the-Loop, CHROOT Sandbox na pliki)

## 5. Autonomia i Odporność (Self-Evolving & Immunity)
- [x] Garbage Collection (Temporal Nodes & Time-to-live / Entropy)
- [x] System odpornościowy (Mutator & Judge)

## 6. Graph RAG (Długoterminowy Kontekst)
- [x] Implementacja Embeddings przez Ollama (mxbai-embed-large)
- [x] Wdrożenie ChromaDB na twardy dysk w [HybridStore](file:///c:/Users/Endorfinka/Desktop/ZBIERACZ%20KODU/GraphMindOS/core/storage/hybrid_store.py#6-103)
- [x] Dodanie Atomów Sensorycznych (read_file, read_directory)

## 7. Autonomiczna Fabryka Kodów (Tool Designer)
- [ ] Opracowanie mechanizmu DynamicPrimitiveLoader
- [ ] Stworzenie modułu `tool_designer.py` (LLM Code Generation)
- [ ] Dodanie Sanity-Check i zatwierdzenia przez człowieka (Human-Review Node)
