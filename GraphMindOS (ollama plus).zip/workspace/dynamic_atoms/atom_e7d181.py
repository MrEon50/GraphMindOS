from core.engine.primitives import PrimitiveRegistry
import os

try:
    import psutil
except ImportError:
    psutil = None

@PrimitiveRegistry.register("system_resources")
def system_resources(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("Missing or invalid payload data: expected a dictionary")
    
    cpu_count = os.cpu_count()
    if cpu_count is None:
        cpu_count = 1
        
    memory_info = {}
    if psutil:
        mem = psutil.virtual_memory()
        memory_info = {
            "ram_total_mb": mem.total,
            "ram_used_mb": mem.used
        }
    else:
        memory_info = {
            "ram_total_mb": 0,
            "ram_used_mb": 0
        }
    
    return {
        "cpu_cores": cpu_count,
        **memory_info
    }