import requests
import urllib.parse
from bs4 import BeautifulSoup
from core.engine.primitives import PrimitiveRegistry

@PrimitiveRegistry.register("duckduckgo_search")
def duckduckgo_search(payload: dict) -> dict:
    if 'query' not in payload or not payload['query']:
        raise ValueError("Missing or empty 'query' in payload")

    encoded_query = urllib.parse.quote(payload['query'])
    url = f"https://html.duckduckgo.com/html/?q={encoded_query}"

    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        text_content = soup.get_text(separator=' ', strip=True)
        
        return {
            "search_results": text_content[:500]
        }
    except requests.RequestException as e:
        raise Exception(f"Network error occurred: {e}")