from core.engine.primitives import PrimitiveRegistry
import os

@PrimitiveRegistry.register("delete_file")
def delete_file(payload: dict) -> dict:
    if "filepath" not in payload:
        raise ValueError("Missing required field 'filepath' in payload")
    
    filepath = payload["filepath"]
    
    if not os.path.exists(filepath):
        raise ValueError(f"File path does not exist: {filepath}")
        
    try:
        os.remove(filepath)
    except OSError:
        raise ValueError(f"Failed to delete file: {filepath}")
        
    return {"deleted": True}