from core.engine.primitives import PrimitiveRegistry
import os

@PrimitiveRegistry.register("write_file")
def write_file(payload: dict) -> dict:
    # Validacja obecności wymaganych kluczy
    if "path" not in payload:
        raise ValueError("Missing required field: path")
    if "content" not in payload:
        raise ValueError("Missing required field: content")
    
    path = payload["path"]
    content = payload["content"]
    
    # Konwersja ścieżki na pełną ścieżkę abelowaną
    abs_path = os.path.abspath(path)
    
    try:
        # Bezpieczne zapisywanie pliku w trybie 'w' z obsługą kontekstu
        with open(abs_path, "w", encoding="utf-8") as f:
            f.write(content)
        return {"status": "success", "message": "File written successfully"}
    except (IOError, OSError, PermissionError) as e:
        # Zgłaszanie błędów operacyjnych jako ValueError zgodnie z zasadami
        raise ValueError(f"Failed to write file: {e}")