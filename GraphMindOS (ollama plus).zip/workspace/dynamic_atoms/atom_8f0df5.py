from core.engine.primitives import PrimitiveRegistry
from datetime import datetime

@PrimitiveRegistry.register("get_datetime")
def get_datetime(payload: dict) -> dict:
    if payload is None:
        raise ValueError("Payload is missing")
    
    if not isinstance(payload, dict):
        raise ValueError("Payload must be a dictionary")

    try:
        current_time = datetime.now()
        formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        
        return {"current_time": formatted_time}
    except Exception:
        raise ValueError("Failed to process datetime")