from core.engine.primitives import PrimitiveRegistry

@PrimitiveRegistry.register("write_file")
def write_file(payload: dict) -> dict:
    if "filepath" not in payload:
        raise ValueError("Missing required field: filepath")
    if "content" not in payload:
        raise ValueError("Missing required field: content")

    filepath = payload["filepath"]
    content = payload["content"]

    with open(filepath, "w") as f:
        f.write(content)

    return {"status": "success", "written_bytes": len(content)}