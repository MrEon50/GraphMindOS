import json
import urllib.request
import urllib.error
from core.intent.compiler import IntentCompiler
from core.engine.primitives import PrimitiveRegistry

compiler = IntentCompiler(model_name="qwen3.5:9b")
intent1 = "Wykorzystaj atom 'system_resources', a następnie użyj atoma 'write_file'. Jako filepath wpisz './workspace/raport.txt'. Zapisz te użyteczne dane dla mnie w tamtym pliku. Zwróć uwagę by dać dobre payload."

payload = {
    "model": compiler.model_name,
    "messages": [
        {"role": "system", "content": compiler.system_prompt + f"\n\nAKTUALNIE DOSTĘPNE NARZĘDZIA (ATOMY), KTÓRE MOŻESZ WYKORZYSTAĆ W 'processor_ref': ['write_file', 'delete_file', 'get_datetime', 'system_resources', 'duckduckgo_search']"},
        {"role": "user", "content": f"Skompiluj proszę tę intencję: {intent1}"}
    ],
    "stream": False,
    "format": "json"
}

req = urllib.request.Request(
    compiler.endpoint, 
    data=json.dumps(payload).encode('utf-8'),
    headers={'Content-Type': 'application/json'}
)
try:
    with urllib.request.urlopen(req) as response:
        result = json.loads(response.read().decode('utf-8'))
        raw_content = result.get("message", {}).get("content", "")
        print("RAW CONTENT:", raw_content)
except Exception as e:
    print("ERR:", e)
