import logging
from core.intent.compiler import IntentCompiler
from core.engine.primitives import PrimitiveRegistry

# Simulate dynamic loading
from workspace.dynamic_atoms import atom_00775e, atom_7fe612, atom_8f0df5, atom_e7d181, atom_f70b47

compiler = IntentCompiler(model_name="qwen3.5:9b")
intent1 = "Wykorzystaj atom 'system_resources', a następnie użyj atoma 'write_file'. Jako filepath wpisz './workspace/raport.txt'. Zapisz te użyteczne dane dla mnie w tamtym pliku. Zwróć uwagę by dać dobre payload."

print("Running compile_intent...")
nodes = compiler.compile_intent(intent1)
print(f"Nodes compiled: {len(nodes)}")
for n in nodes:
    print("-", n.nodeId, n.execution.processor_ref)
