import json
import urllib.request
import socket
import os
import re
import time
from core.standards import get_standards_for_prompt

class ToolDesigner:
    """
    LLM-based component that autonomously generates new Primitive code
    based on user requests. It ensures the code follows the registry format.
    Uses /api/chat endpoint for better stability with local models.
    """
    def __init__(self, model_name: str = "qwen3.5:9b", endpoint: str = "http://localhost:11434/api/chat"):
        self.model_name = model_name
        self.endpoint = endpoint
        self.max_retries = 3
        
        standards = get_standards_for_prompt()
        self.system_prompt = f"""Napisz kod Python definiujacy nowy Atom dla systemu GraphMindOS.

Zasady:
1. Import: from core.engine.primitives import PrimitiveRegistry
2. Dekorator: @PrimitiveRegistry.register("nazwa_atoma", "Krotki opis. Przyjmuje: klucz1, klucz2.")
3. Funkcja: def nazwa(payload: dict) -> dict
4. Obsluga bledow: raise ValueError z czytelnym komunikatem (NIE zwracaj dict z error).
5. Zwroc TYLKO blok ```python ... ``` bez innego tekstu.

{standards}

Atom MUSI:
- Szukac danych pod wieloma kluczami: payload.get("filepath") or payload.get("filename") or payload.get("path")
- Rzucac ValueError na bledy, nie zwracac w dict np: {{"error": "zly"}}.
- Zwracac wynik pod standardowym kluczem"""

    def design_tool(self, description: str) -> str:
        payload = {
            "model": self.model_name,
            "messages": [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": f"Napisz Atom: {description}"}
            ],
            "stream": False
        }
        
        for attempt in range(1, self.max_retries + 1):
            try:
                req = urllib.request.Request(
                    self.endpoint,
                    data=json.dumps(payload).encode('utf-8'),
                    headers={'Content-Type': 'application/json'}
                )
                timeout = 60 * attempt  # 60s, 120s, 180s
                print(f"[TOOL DESIGNER] Projektowanie kodu (proba {attempt}/{self.max_retries}, timeout: {timeout}s)...")
                
                with urllib.request.urlopen(req, timeout=timeout) as response:
                    result = json.loads(response.read().decode('utf-8'))
                    raw_code = result.get("message", {}).get("content", "")
                    
                    # Ekstrakcja kodu z blokow markdown
                    match = re.search(r'```(?:python)?\s*(.*?)\s*```', raw_code, re.DOTALL)
                    if match:
                        code = match.group(1).strip()
                    else:
                        code = raw_code.strip()
                    
                    if code and "def " in code:
                        return code
                    else:
                        print(f"[TOOL DESIGNER] Model nie zwrocil poprawnego kodu. Ponawiam...")
                        continue
                        
            except socket.timeout:
                print(f"[TOOL DESIGNER] Timeout (proba {attempt}/{self.max_retries}). Model mysli zbyt dlugo.")
                if attempt < self.max_retries:
                    wait = 3 * attempt
                    print(f"[TOOL DESIGNER] Czekam {wait}s przed kolejna proba...")
                    time.sleep(wait)
                    
            except urllib.error.HTTPError as e:
                print(f"[TOOL DESIGNER] Ollama zwrocila blad HTTP {e.code} (proba {attempt}/{self.max_retries}).")
                if e.code == 500:
                    print(f"[TOOL DESIGNER] Blad wewnetrzny Ollamy. Mozliwe przeciazenie pamieci modelu.")
                    if attempt < self.max_retries:
                        wait = 5 * attempt
                        print(f"[TOOL DESIGNER] Czekam {wait}s i ponawiam z dluzszysp timeoutem...")
                        time.sleep(wait)
                else:
                    break
                    
            except Exception as e:
                print(f"[TOOL DESIGNER] Nieoczekiwany blad: {e}")
                break
        
        print(f"[TOOL DESIGNER] Nie udalo sie wygenerowac kodu po {self.max_retries} probach.")
        return ""

    def validate_code(self, source_code: str) -> bool:
        """
        Walidacja bezpieczenstwa z systemem ostrzezen Human-in-the-Loop.
        Zamiast slepego blokowania, edukuje uzytkownika i pyta o decyzje.
        """
        # Slownik zagrozen z opisami dla uzytkownika
        dangerous_patterns = {
            "os.system": "Uruchamia dowolna komende systemowa bez kontroli. Moze usunac pliki, zmienic ustawienia systemu lub uruchomic szkodliwe programy.",
            "subprocess": "Daje pelny dostep do konsoli (CMD/PowerShell). Pozwala uruchamiac programy, skrypty .bat i komendy systemowe z poziomu kodu.",
            "eval(": "Wykonuje dowolny kod Python podany jako tekst. Moze byc wykorzystany do wstrzykniecia zlowrogiego kodu.",
            "exec(": "Wykonuje dynamicznie wygenerowany kod Python. Podobne zagrozenie jak eval - brak kontroli nad tym co zostanie uruchomione.",
            "__import__": "Pozwala na dynamiczne ladowanie dowolnych modulow Pythona, omijajac standardowe importy i zabezpieczenia."
        }
        
        # Sprawdz strukture kodu (to MUSI byc spelnione - bez negocjacji)
        if "@PrimitiveRegistry.register" not in source_code:
            print("[JUDGE] Kod odrzucony: Brak wymaganego dekoratora @PrimitiveRegistry.register.")
            return False
        if "def " not in source_code:
            print("[JUDGE] Kod odrzucony: Brak definicji funkcji (def).")
            return False
        
        # Sprawdz niebezpieczne wzorce - OSTRZEGAJ zamiast blokowac
        found_dangers = []
        for pattern, explanation in dangerous_patterns.items():
            if pattern in source_code:
                found_dangers.append((pattern, explanation))
        
        if found_dangers:
            print("\n" + "!" * 50)
            print("[JUDGE] UWAGA! WYKRYTO ELEMENTY WYMAGAJACE SWIADOMEJ DECYZJI!")
            print("!" * 50)
            print("\nWygenerowany kod zawiera nastepujace elementy:")
            for i, (pattern, explanation) in enumerate(found_dangers, 1):
                print(f"\n  {i}. '{pattern}':")
                print(f"     -> {explanation}")
            print("\n" + "!" * 50)
            print("Ten kod daje narzedziu wieksze uprawnienia niz standardowe Atomy.")
            print("Jesli rozumiesz ryzyko i swiadomie chcesz kontynuowac,")
            print("wcisnij [Y]. Jesli nie jestes pewien, wcisnij [N].")
            print("!" * 50)
            
            while True:
                choice = input("\nCzy zatwierdzasz instalacje tego kodu? [Y/N]: ").strip().lower()
                if choice in ['y', 'yes']:
                    print("[JUDGE] Uzytkownik swiadomie zatwierdzil kod z rozszerzonymi uprawnieniami.")
                    return True
                elif choice in ['n', 'no']:
                    print("[JUDGE] Uzytkownik odmowil. Kod zostal odrzucony.")
                    return False
                else:
                    print("[!] Wpisz Y lub N.")
        
        return True
