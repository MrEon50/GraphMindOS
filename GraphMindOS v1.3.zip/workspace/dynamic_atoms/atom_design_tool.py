from core.engine.primitives import PrimitiveRegistry
from core.evolution.tool_designer import ToolDesigner
import uuid
import os

@PrimitiveRegistry.register("design_atom", "Autonomiczna Kuźnia. Tworzy nowy Atom w locie. Wymaga: text (opis czego potrzebuje nowe narzędzie).")
def design_atom(payload: dict) -> dict:
    concept = payload.get("text") or payload.get("text_content") or payload.get("content") or payload.get("message")
    
    if not concept:
        raise ValueError("Kuźnia wymaga opisu narzędzia w kluczu 'text' lub 'message'.")
        
    print(f"[KUŹNIA NARZĘDZI] Rozpoczynam kucie narzędzia pod koncept: '{concept}'")
    
    designer = ToolDesigner()
    max_forge_attempts = 3
    new_code = ""
    current_prompt = concept
    
    for attempt in range(1, max_forge_attempts + 1):
        print(f"[KUŹNIA NARZĘDZI] Kucie (Próba {attempt}/{max_forge_attempts})...")
        new_code = designer.design_tool(current_prompt)
        
        if not new_code or "def " not in new_code:
            current_prompt = f"ZROBIŁEŚ BŁĄD. Twój kod musi zawierać w pełni poprawną logikę Pythona (def nazwa_narzedzia(payload)). Spróbuj jeszcze raz dla konceptu: {concept}"
            continue
            
        # Pół-Piaskownica (AST Compile Check)
        try:
            compile(new_code, '<string>', 'exec')
            # Jeżeli doszło tutaj - kod jest wolny od IndentationError i SyntaxError
            print("[KUŹNIA NARZĘDZI] Kod pomyślnie przeszedł weryfikację składni (AST Check).")
            break
        except SyntaxError as e:
            print(f"[KUŹNIA NARZĘDZI] Bład składniowy w wygenerowanym kodzie: {e}")
            current_prompt = f"Twój poprzedni kod zepsuł się SyntaxErrorem w linii {e.lineno}: {e.msg}\nMusi to być poprawny kod przestrzeni GraphMindOS.\nPopraw kod dla: {concept}"
        except Exception as e:
            print(f"[KUŹNIA NARZĘDZI] Krytyczny błąd struktury kodu: {e}")
            current_prompt = f"Błąd Python: {e}\nPopraw kod dla: {concept}"
            
    else:
        raise ValueError("Kuźnia zawiodła: Model nie wygenerował poprawnego kodu po 3 próbach samo-naprawy.")
        
    # UWAGA: W wersji autonomicznej (bez Human-in-The-Loop) ucinamy validate_code(input) by graf się nie zatrzymał na [Y/N].
    # Zamiast tego wdrażamy plik bezpośrednio. 
    # Bezpieczeństwo zapewnia fakt, że model wiecznie operuje w lokalnym środowisku 
    # (chociaż docelowo powinna tu wejść piaskownica).
    
    dynamic_dir = os.path.abspath(os.path.join(os.getcwd(), "workspace", "dynamic_atoms"))
    safe_filename = f"atom_{uuid.uuid4().hex[:6]}.py"
    file_path = os.path.join(dynamic_dir, safe_filename)
    
    os.makedirs(dynamic_dir, exist_ok=True)
    
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(new_code)
        
    print(f"[KUŹNIA NARZĘDZI] Wykuto zmysł! Zapisano jako: {safe_filename}")
    
    # Reload do RAMu w tym samym ułamku sekundy
    PrimitiveRegistry.load_dynamic_atoms()
    
    return {
        "status": "success",
        "message": f"Narzędzie zostało stworzone i załadowane z pliku {safe_filename}.",
        "filepath": file_path
    }
