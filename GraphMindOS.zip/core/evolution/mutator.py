import json
import urllib.request
from typing import Optional
from core.models.node import GraphNode

class SandboxMutator:
    """
    Self-Evolving Mutator Sandbox.
    System Immunologiczny GraphMindOS. Łapie uszkodzony węzeł (tzw. stan zapalny), 
    prosi LLM o wygenerowanie rekonfiguracji/łatki grafu (Mutacja),
    odpala to wirtualnie ze Sędzią (Judge Sandbox) i naprawia w locie GraphDB.
    """
    def __init__(self, model_name: str = "qwen3.5:9b", endpoint: str = "http://localhost:11434/api/chat"):
        self.model_name = model_name
        self.endpoint = endpoint
        self.system_prompt = """
        Jesteś Agentem-Mutatorem i Sędzią (Judge) w systemie GraphMindOS. Twoje zadanie to 'Self-Healing'.
        Jeden z węzłów w grafie wykonawczym zgłosił awarię (Status: Failed). 
        Otrzymasz zrzut węzła (JSON) oraz treść błędu (Exception z pythona na Atomie ewaluacyjnym).
        
        ZABIEG RATUNKOWY (MUTATION):
        - Znajdź przyczynę błędu (np. brakujący argument w 'payload', zła nazwa w 'processor_ref').
        - Zwróć JEDEN naprawiony zrzut tego węzła w czystym JSON (bez markdown).
        - Wypełnij 'payload' odpowiednimi kluczami na podstawie błędu.
        """

    def heal_node(self, failed_node: GraphNode, error_msg: str) -> Optional[GraphNode]:
        print(f"\n[MUTATOR SANDBOX] Wykryto uszkodzony węzeł '{failed_node.nodeId}'. Inicjuję ewolucyjną rekonfigurację.")
        print(f"[MUTATOR SANDBOX] Raport patologii: {error_msg}")
        
        node_json = failed_node.json()
        
        payload = {
            "model": self.model_name,
            "messages": [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": f"WĘZEŁ (JSON): {node_json}\n\nRAPORT Z AWARII: {error_msg}\n\nWygeneruj patch JSON z poprawionym payloadem lub ref."}
            ],
            "stream": False,
            "format": "json"
        }
        
        try:
            req = urllib.request.Request(
                self.endpoint, 
                data=json.dumps(payload).encode('utf-8'),
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read().decode('utf-8'))
                
            raw_content = result.get("message", {}).get("content", "")
            if raw_content.startswith("```json"):
                raw_content = raw_content[7:]
            if raw_content.endswith("```"):
                raw_content = raw_content[:-3]
                
            data = json.loads(raw_content.strip())
            
            # Wdrażamy patcha (Mutację)
            healed_node = failed_node.copy(deep=True)
            if "execution" in data:
                if "processor_ref" in data["execution"]:
                    healed_node.execution.processor_ref = data["execution"]["processor_ref"]
                if "payload" in data["execution"]:
                    healed_node.execution.payload = data["execution"]["payload"]
                    
            print(f"[JUDGE] Patch wygenerowany. Zaktualizowany Payload: {healed_node.execution.payload}")
            return healed_node
            
        except Exception as e:
            print(f"[MUTATOR] Błąd podczas mutacji (LLM Timeout or Parse Error): {e}")
            return None

    def run_sandbox_judge(self, healed_node: GraphNode) -> bool:
        # Prawdziwy sandbox izoluje wykonanie na Wasm. Tutaj robimy symulowany przegląd logiki:
        print("[JUDGE] Symulacja wykonania nowej topologii w izolacji (Virtual Run)...")
        if healed_node and healed_node.execution.payload and len(healed_node.execution.payload.keys()) > 0:
            print("[JUDGE] Test udany. Węzeł nie zgłasza błędu pustych parametrów. Wdrażam łatkę.")
            return True
        print("[JUDGE] Mutacja nieudana - łatka odrzucona przez wirtualne środowisko.")
        return False
