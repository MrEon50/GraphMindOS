import json
import urllib.request
import os
import re

class ToolDesigner:
    """
    LLM-based component that autonomously generates new Primitive code
    based on user requests. It ensures the code follows the registry format.
    """
    def __init__(self, model_name: str = "qwen3.5:9b", endpoint: str = "http://localhost:11434/api/generate"):
        self.model_name = model_name
        self.endpoint = endpoint
        self.system_prompt = '''Jesteś Głównym Architektem (AI Tool Designer) systemu GraphMindOS.
Twoim zadaniem jest napisanie poprawnego pliku w Pythonie, który definiuje nowy Atom (Primitive) na podstawie żądania użytkownika.
Zasady:
1. Musisz zaimportować PrimitiveRegistry: `from core.engine.primitives import PrimitiveRegistry`
2. Musisz udekorować funkcję: `@PrimitiveRegistry.register("nazwa_atoma")`
3. Funkcja ma przyjmować JEDEN argument `payload: dict` i zwracać `dict`.
4. Funkcja musi posiadać obsługę błędów, by podnosiła Exception/ValueError przy brakujących danych.
5. Nie dodawaj pomyłek bezpieczeństwa (jak `os.system`).
6. ZWRÓĆ TYLKO I WYŁĄCZNIE CZYSTY KOD PYTHON ujęty w bloki ```python ... ``` BEZ ŻADNEGO INNEGO TEKSTU.
'''

    def design_tool(self, description: str) -> str:
        payload = {
            "model": self.model_name,
            "prompt": f"{self.system_prompt}\n\nOpis Atoma do zakodowania: {description}",
            "stream": False
        }
        
        try:
            req = urllib.request.Request(
                self.endpoint,
                data=json.dumps(payload).encode('utf-8'),
                headers={'Content-Type': 'application/json'}
            )
            print("[TOOL DESIGNER] Projektowanie kodu w toku. To może chwilę potrwać...")
            with urllib.request.urlopen(req, timeout=120) as response:
                result = json.loads(response.read().decode('utf-8'))
                raw_code = result.get("response", "")
                
                # Ekstrakcja kodu z bloków markdown (```python ... ```)
                match = re.search(r'```(?:python)?(.*?)```', raw_code, re.DOTALL)
                if match:
                    code = match.group(1).strip()
                else:
                    # Fallback jesli zwrocono czysty tekst
                    code = raw_code.strip()
                return code
        except Exception as e:
            print(f"[TOOL DESIGNER] Błąd LLM podczas generowania kodu: {e}")
            return ""

    def validate_code(self, source_code: str) -> bool:
        """
        Bardzo prosta, wstępna walidacja przed zapytaniem użytkownika.
        (Odrzuca trywialne pomyłki z imporem os.system itp.)
        """
        if "os.system" in source_code or "subprocess" in source_code:
            print("[JUDGE] Kod odrzucony: Wykryto niebezpieczne wywołania basha (os.system/subprocess).")
            return False
        if "@PrimitiveRegistry.register" not in source_code:
            print("[JUDGE] Kod odrzucony: Brak wymaganego dekoratora rejestrującego @PrimitiveRegistry.")
            return False
        return True
