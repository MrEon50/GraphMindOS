from typing import Optional, List, Dict, Any
from core.models.node import GraphNode

class HybridStore:
    """
    Abstrakcja bazy hybrydowej (Zastąpiłoby Neo4j + Milvus w produkcji).
    Obecnie symulowane jako in-memory dla łatwych testów architektury GraphMindOS.
    """
    def __init__(self):
        self._nodes: Dict[str, GraphNode] = {}
        
    def add_node(self, node: GraphNode):
        self._nodes[node.nodeId] = node
        print(f"[STORE] Added node {node.nodeId} ({node.kind})")
        
    def get_node(self, node_id: str) -> Optional[GraphNode]:
        return self._nodes.get(node_id)
        
    def update_node(self, node: GraphNode):
        if node.nodeId in self._nodes:
            self._nodes[node.nodeId] = node
            
    def query_semantic(self, vector: List[float], top_k: int = 5) -> List[GraphNode]:
        # Symulacja wyszukiwania wektorowego (Qdrant)
        # W rzeczywistości obliczano by cosine similarity
        return list(self._nodes.values())[:top_k]

    def remove_node(self, node_id: str):
        if node_id in self._nodes:
            del self._nodes[node_id]
            print(f"[STORE - ENTROPY] Node {node_id} removed (decayed).")

    def process_entropy(self):
        """
        System Garbage Collection uaktywniany np. co tick / zdarzenie.
        """
        nodes_to_remove = []
        for n_id, node in self._nodes.items():
            if node.entropy.is_ephemeral and node.entropy.decay_rate > 0:
                node.entropy.lifespan -= node.entropy.decay_rate
                if node.entropy.lifespan <= 0:
                    nodes_to_remove.append(n_id)
        
        for n_id in nodes_to_remove:
            self.remove_node(n_id)

