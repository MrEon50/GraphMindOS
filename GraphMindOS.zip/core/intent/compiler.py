import json
import urllib.request
import urllib.error
from typing import List, Dict, Any
from core.models.node import GraphNode, Topology, Relationship, Execution, Entropy

class IntentCompiler:
    """
    Kompilator Intencji. Łączy się z lokalnym modelem Ollama, 
    aby przetłumaczyć język naturalny na sub-graf (DAG) zgodny z GraphMindOS.
    """
    
    def __init__(self, model_name: str = "qwen2.5-coder:14b-instruct-q8_0", endpoint: str = "http://localhost:11434/api/chat"):
        self.model_name = model_name
        self.endpoint = endpoint
        
        # System prompt wymuszający ścisłą strukturę wyjściową.
        self.system_prompt = """
Jesteś Głównym Kompilatorem Intencji (Intent Compiler) w systemie GraphMindOS.
Twoim zadaniem jest zamiana żądania użytkownika (język naturalny) w graf akcji (Topologię) ustandaryzowaną jako JSON.

Założenia GraphMindOS:
- Graf składa się z węzłów. Każdy węzeł ma 'nodeId'.
- Węzły mogą być 3 rodzajów (kind):
  1. 'intent' (punkt wejścia z żądania)
  2. 'primitive' (Atom wykonawczy, np. ma wpisane execution.processor_ref = 'math_add', 'log_message', etc.)
  3. 'state' (Przechowuje twardy wynik logiki)
- 'processor_ref': Musisz go dobrać intuicyjnie do zadania (np. 'fetch_weather', 'read_file', 'log_message', 'calculate').
- 'topology.outputs' to krawędzie grafu, po których spaceruje RoutingEngine. Mają 'targetId', 'weight' i opcjonalnie 'condition' (w formie kodu Python Evaluator, np. 'result > 10').
- 'entropy': 'is_ephemeral' = true (znika) lub false (zostaje w bazie). 'decay_rate' to erozja żywotności w taktach (od 0.0 do 1.0), 'lifespan' to początkowa "energia" węzła.

MUSISZ ZWRÓCIĆ **TYLKO** CZYSTY JSON w poniższym schemacie, be tagów ```json i bez żadnego tekstu pobocznego.
Schemat Wyjściowy (Output JSON Schema):
{
  "nodes": [
    {
      "nodeId": "string (unikalne)",
      "kind": "intent, primitive, lub state",
      "execution": {
        "processor_ref": "nazwa opcjonalnego atomu (dla primitive)",
        "payload": {}
      },
      "topology": {
        "outputs": [
          {"targetId": "string", "relationshipType": "string", "weight": float, "condition": "string"}
        ]
      },
      "entropy": {
        "lifespan": float,
        "decay_rate": float,
        "is_ephemeral": boolean
      }
    }
  ]
}
"""

    def compile_intent(self, user_intent: str) -> List[GraphNode]:
        print(f"[COMPILER] Translating Intent via Ollama ({self.model_name}): '{user_intent}'")
        
        payload = {
            "model": self.model_name,
            "messages": [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": f"Skompiluj proszę tę intencję: {user_intent}"}
            ],
            "stream": False,
            "format": "json" # Ollama natywnie wspiera wymuszanie JSON
        }
        
        try:
            req = urllib.request.Request(
                self.endpoint, 
                data=json.dumps(payload).encode('utf-8'),
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read().decode('utf-8'))
                
            raw_content = result.get("message", {}).get("content", "")
            
            # Bezpieczne usunięcie nadmiarowych znaczników (czasami format: json w Ollama przepuszcza tagi)
            if raw_content.startswith("```json"):
                raw_content = raw_content[7:]
            if raw_content.endswith("```"):
                raw_content = raw_content[:-3]
                
            data = json.loads(raw_content.strip())
            
            # Ekstrakcja do modeli GraphNode (Pydantic zrobi walidację)
            nodes = []
            for node_data in data.get("nodes", []):
                
                # Budowanie złożonych obiektów ręcznie z dict
                execution_data = node_data.get("execution", {})
                exc = Execution(
                    processor_ref=execution_data.get("processor_ref"),
                    payload=execution_data.get("payload", {})
                )
                
                topo_data = node_data.get("topology", {})
                outputs = []
                for out_data in topo_data.get("outputs", []):
                    outputs.append(Relationship(**out_data))
                topo = Topology(outputs=outputs)
                
                ent_data = node_data.get("entropy", {})
                ent = Entropy(**ent_data)
                
                node = GraphNode(
                    nodeId=node_data.get("nodeId"),
                    kind=node_data.get("kind"),
                    execution=exc,
                    topology=topo,
                    entropy=ent
                )
                nodes.append(node)
                
            print(f"[COMPILER] Successfully compiled {len(nodes)} nodes.")
            return nodes
            
        except urllib.error.URLError as e:
            print(f"[COMPILER] Nie można połączyć się z Ollama: {e}. Upewnij się, że lokalny serwer działa na porcie 11434.")
            return []
        except Exception as e:
            print(f"[COMPILER] Błąd parsowania wyjścia LLM: {e}")
            return []
