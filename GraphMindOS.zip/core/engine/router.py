from core.storage.hybrid_store import HybridStore
from core.models.node import GraphNode, Relationship
from core.engine.evaluator import SafeEvaluator
from core.engine.primitives import PrimitiveRegistry
import time

class RoutingEngine:
    """
    Egzekutor Logiki oparty na DAG i wagach przejść.
    Zamiast używać if/else, przechodzi zapisaną Topologię.
    """
    def __init__(self, store: HybridStore, max_depth: int = 50):
        self.store = store
        self.max_depth = max_depth

    def execute_node(self, node_id: str, depth: int = 0):
        if depth > self.max_depth:
            print(f"[ENGINE-ALERT] Infinite loop detected at recursion depth {depth}! Halting topology branch.")
            # Tutaj w przyszłości "Mutator Sandbox" dostanie zgłoszenie
            return

        node = self.store.get_node(node_id)
        if not node:
            return
            
        print(f"[ENGINE] Executing node: {node_id} (Kind: {node.kind})")
        
        # Wykonanie Atoma (Primitive)
        if node.kind == "primitive":
            node.execution.status = "running"
            
            if node.execution.payload is None:
                node.execution.payload = {}
                
            # Jeżeli ma przypisany kod referencyjny Atoma
            if node.execution.processor_ref:
                try:
                    result = PrimitiveRegistry.execute(node.execution.processor_ref, node.execution.payload)
                    node.execution.payload.update(result)
                    node.execution.status = "completed"
                except Exception as e:
                    print(f"   -> [!] Atom Execution Failed: {e}")
                    node.execution.status = "failed"
            else:
                # Fallback, jeżeli pusty primitive
                node.execution.status = "completed"
                
            print(f"   -> Atom status: {node.execution.status}")
        
        # Nawigacja i routing (szukanie wyjść)
        outputs = node.topology.outputs
        # Ewolucyjne sortowanie dróg po najwyższej wadze
        sorted_outputs = sorted(outputs, key=lambda x: x.weight, reverse=True)
        
        dispatched = False
        for out in sorted_outputs:
            if SafeEvaluator.evaluate(out.condition, node.execution.payload):
                print(f"   -> Routing to {out.targetId} (Weight: {out.weight})")
                dispatched = True
                # Uruchamiamy rekurencyjnie lub przez kolejkę asynchroniczną (RabbitMQ/Kafka)
                self.execute_node(out.targetId, depth=depth + 1)
                break
                
        if not dispatched and len(sorted_outputs) > 0:
            print(f"   -> [!] No outputs satisfied conditions for node: {node_id}")
            node.execution.status = "failed"

