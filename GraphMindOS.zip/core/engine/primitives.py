from typing import Callable, Dict, Any
import os
import time
import urllib.request
import urllib.error
import json
import importlib.util
import sys
from bs4 import BeautifulSoup

class PrimitiveRegistry:
    """
    Rejestr 'Atomów Wykonawczych' (Execution Primitives).
    Są to gotowe funkcje (czarne skrzynki) przypisywane do węzłów w grafie.
    Węzeł definiuje: execution.processor_ref = 'fetch_weather' a Rejestr go znajduje.
    """
    
    _registry: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {}

    @classmethod
    def register(cls, name: str):
        def wrapper(func):
            cls._registry[name] = func
            return func
        return wrapper

    @classmethod
    def execute(cls, ref: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        if ref not in cls._registry:
            raise KeyError(f"Primitive Atom '{ref}' not found in registry!")
            
        print(f"[REJESTR] Executing registered primitive: {ref}")
        try:
            return cls._registry[ref](payload)
        except Exception as e:
            print(f"[REJESTR] Error in '{ref}': {e}")
            raise e

    @classmethod
    def load_dynamic_atoms(cls):
        """Hot-Swap ładowanie customowych atomów usera."""
        dynamic_dir = os.path.abspath(os.path.join(os.getcwd(), "workspace", "dynamic_atoms"))
        if not os.path.exists(dynamic_dir):
            os.makedirs(dynamic_dir)
            return
            
        count = 0
        for filename in os.listdir(dynamic_dir):
            if filename.endswith(".py") and not filename.startswith("__"):
                file_path = os.path.join(dynamic_dir, filename)
                module_name = f"dynamic_atom_{filename[:-3]}"
                
                # Dynamiczny load modułu do pythonsys
                spec = importlib.util.spec_from_file_location(module_name, file_path)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[module_name] = module
                    try:
                        spec.loader.exec_module(module)
                        count += 1
                    except Exception as e:
                        print(f"🔧 [LOADER ERROR] Nie udalo sie załadowac Atoma z pliku '{filename}': {e}")
                        
        if count > 0:
            print(f"🔧 [TOOL LOADER]: Pomyślnie załadowano {count} dynamicznych autorskich Atomów do rdzenia OS!")

# --- Przykładowe Atomy dla testów demówki ---

@PrimitiveRegistry.register("calculate_salary")
def calculate_salary(payload: dict) -> dict:
    hours = payload.get("hours", payload.get("hours_worked"))
    rate = payload.get("rate_per_hour", payload.get("hourly_rate"))
    
    if hours is None or rate is None:
        raise ValueError(f"CRITICAL: Atom 'calculate_salary' wymaga w payloadzie kluczy: 'hours' oraz 'rate_per_hour', otrzymano: {list(payload.keys())}")
        
    salary = hours * rate
    print(f">> [PRIMITIVE PAYROLL]: Calculated Salary: {salary} <<")
    return {"result": salary}

@PrimitiveRegistry.register("log_message")
def log_message(payload: dict) -> dict:
    msg = payload.get("message", "No message provided")
    print(f">> [PRIMITIVE LOG]: {msg} <<")
    return {"logged": True, "message_length": len(msg)}

# --- Sensory Atomy dla Bezpiecznego RAG (Chroot & File IO) ---

@PrimitiveRegistry.register("read_directory")
def read_directory(payload: dict) -> dict:
    folder = payload.get("path", ".")
    abs_path = os.path.abspath(folder)
    
    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"[ERROR] Katalog nie istnieje: {abs_path}")
        
    try:
        files = os.listdir(abs_path)
    except Exception as e:
        raise PermissionError(f"[OS ERROR] System zabronił czytać tego miejsca: {e}")
        
    print(f"📖 [PRIMITIVE FS]: Przeczytano strukturę: {abs_path} ({len(files)} items)")
    return {"files": files, "path_scanned": abs_path}

@PrimitiveRegistry.register("read_file")
def read_file(payload: dict) -> dict:
    filename = payload.get("filename", "")
    abs_path = os.path.abspath(filename)
    
    if not os.path.isfile(abs_path):
        raise FileNotFoundError(f"[ERROR] Plik nie istnieje: {abs_path}")
        
    with open(abs_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
        
    print(f"📄 [PRIMITIVE FS]: Przeczytano plik: {abs_path} ({len(content)} znaków)")
    return {"text_content": content, "filename": abs_path}

@PrimitiveRegistry.register("ask_user_permission")
def ask_user_permission(payload: dict) -> dict:
    """
    KRYTYCZNY WĘZEŁ - Human-in-the-loop.
    Zatrzymuje spacer grafu, pyta usera z terminala o zgodę na działanie zagrażające.
    """
    action = payload.get("action_description", "Nieznana ryzykowna akcja")
    consequences = payload.get("consequences", "Brak danych o konsekwencjach. Zachowaj ostrożność!")
    
    print(f"\n" + "="*50)
    print(f"🛑 [HUMAN-IN-THE-LOOP] Wymagana Zgoda")
    print(f"🛑 Agent próbuje zrealizować pod-graf operacji: '{action}'")
    print(f"⚠️  PRZEWIDYWANE KONSEKWENCJE: {consequences}")
    
    while True:
        choice = input(f"Zezwolić na wykonanie? [Y]es / [N]o: ").strip().lower()
        if choice in ['y', 'yes']:
            print(f"✅ Zezwolono ręcznie na: '{action}'")
            print("="*50 + "\n")
            return {"permission_granted": True}
        elif choice in ['n', 'no']:
            print(f"❌ Odmówiono. Wyrzucam błąd zabezpieczenia Autonomii.")
            print("="*50 + "\n")
            raise PermissionError("Użytkownik odmówił wykonania Atoma modyfikującego system.")

# --- Sensory Atomy dla Sieci Internetowej (Web & REST API) ---

@PrimitiveRegistry.register("fetch_webpage")
def fetch_webpage(payload: dict) -> dict:
    """Sensoryczne przeczytanie strony internetowej ze świata (bez wysyłania wrażliwych danych)."""
    url = payload.get("url")
    if not url:
        raise ValueError("[ERROR] Atom 'fetch_webpage' wymaga parametru 'url'.")
        
    print(f"[PRIMITIVE NET]: Pobieranie GET z URLa: {url} ...")
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'GraphMindOS-Spider/1.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8', errors='ignore')
            
        # Zabezpieczenie przed ściągnięciem śmieci HTML do RAM:
        soup = BeautifulSoup(html, "html.parser")
        text = soup.get_text(separator=' ', strip=True)
        print(f"[PRIMITIVE NET]: Wyciągnięto {len(text)} znaków czystego tekstu.")
        
        # Zwracamy text_content by ChromaDB Graph RAG naturalnie zaindeksowała wiedzę
        return {"text_content": text, "url": url}
    except Exception as e:
        raise RuntimeError(f"[PRIMITIVE NET] Sieć odrzuciła uścisk dłoni z {url}: {e}")

@PrimitiveRegistry.register("http_post")
def http_post(payload: dict) -> dict:
    """Niszczycielski lub wrażliwy przekaźnik danych do neta."""
    # BEZWZGLĘDNE ZABEZPIECZENIE (HARD-CODED HARNESS)
    if not payload.get("permission_granted"):
        raise PermissionError(
            "🛑 ZABEZPIECZENIE ANTY-HAKERSKIE 🛑 "
            "Model AI spróbował wysłać POST w otwartą sieć bez węzła Human-in-the-loop "
            "lub nie przekazał logiki permission_granted! Proces ZABITY."
        )

    url = payload.get("url")
    data = payload.get("data", {})
    if not url:
        raise ValueError("[ERROR] Atom 'http_post' wymaga parametru 'url'.")

    print(f"[PRIMITIVE NET]: Bezpieczny Autoryzowany POST do: {url}")
    try:
        encoded_data = json.dumps(data).encode('utf-8')
        req = urllib.request.Request(url, data=encoded_data, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=10) as response:
            result = response.read().decode('utf-8', errors='ignore')
            
        print(f"[PRIMITIVE NET]: Wysłano pomyślnie. Odpowiedź z serwera odebrana.")
        return {"response": result}
    except Exception as e:
        raise RuntimeError(f"[PRIMITIVE NET] Wysłanie POST nie powiodło się: {e}")
