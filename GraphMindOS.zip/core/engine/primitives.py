from typing import Callable, Dict, Any

class PrimitiveRegistry:
    """
    Rejestr 'Atomów Wykonawczych' (Execution Primitives).
    Są to gotowe funkcje (czarne skrzynki) przypisywane do węzłów w grafie.
    Węzeł definiuje: execution.processor_ref = 'fetch_weather' a Rejestr go znajduje.
    """
    
    _registry: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {}

    @classmethod
    def register(cls, name: str):
        def wrapper(func):
            cls._registry[name] = func
            return func
        return wrapper

    @classmethod
    def execute(cls, ref: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        if ref not in cls._registry:
            raise KeyError(f"Primitive Atom '{ref}' not found in registry!")
            
        print(f"[REJESTR] Executing registered primitive: {ref}")
        try:
            return cls._registry[ref](payload)
        except Exception as e:
            print(f"[REJESTR] Error in '{ref}': {e}")
            raise e

# --- Przykładowe Atomy dla testów demówki ---

@PrimitiveRegistry.register("calculate_salary")
def calculate_salary(payload: dict) -> dict:
    hours = payload.get("hours", payload.get("hours_worked"))
    rate = payload.get("rate_per_hour", payload.get("hourly_rate"))
    
    if hours is None or rate is None:
        raise ValueError(f"CRITICAL: Atom 'calculate_salary' wymaga w payloadzie kluczy: 'hours' oraz 'rate_per_hour', otrzymano: {list(payload.keys())}")
        
    salary = hours * rate
    print(f">> [PRIMITIVE PAYROLL]: Calculated Salary: {salary} <<")
    return {"result": salary}

@PrimitiveRegistry.register("log_message")
def log_message(payload: dict) -> dict:
    msg = payload.get("message", "No message provided")
    print(f">> [PRIMITIVE LOG]: {msg} <<")
    return {"logged": True, "message_length": len(msg)}
