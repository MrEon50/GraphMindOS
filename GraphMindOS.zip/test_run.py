from core.models.node import GraphNode, Topology, Relationship, Execution, Entropy
from core.storage.hybrid_store import HybridStore
from core.engine.router import RoutingEngine
from core.engine.primitives import PrimitiveRegistry
from core.engine.router import RoutingEngine

def run_test():
    print("=== GraphMindOS: Core Flow Test ===")
    
    # 1. Inicjalizacja Pamięci i Silnika
    store = HybridStore()
    engine = RoutingEngine(store)
    
    # 2. Tworzenie Węzłów (Symulacja Intencji i Wykonania)
    
    # Węzeł A: Krótkotrwała Intencja
    node_a = GraphNode(
        nodeId="intent_001",
        kind="intent",
        entropy=Entropy(lifespan=1.0, decay_rate=1.0, is_ephemeral=True),
        topology=Topology(
            outputs=[Relationship(targetId="worker_001", relationshipType="triggers", weight=1.0)]
        )
    )
    
    # Węzeł B: Robotnik (Atom Wykonawczy)
    node_b = GraphNode(
        nodeId="worker_001",
        kind="primitive",
        execution=Execution(
            processor_ref="math_add",
            payload={"a": 5, "b": 10}
        ),
        entropy=Entropy(lifespan=1.0, decay_rate=0.5, is_ephemeral=True), # Zniknie po 2 cyklach
        topology=Topology(
            outputs=[
                Relationship(targetId="final_001", relationshipType="passes_to", weight=1.0, condition="result > 10"),
                Relationship(targetId="error_001", relationshipType="fails_to", weight=0.5, condition="result <= 10")
            ]
        )
    )
    
    # Węzeł C: Trwały Wynik (State)
    node_c = GraphNode(
        nodeId="final_001",
        kind="state",
        entropy=Entropy(lifespan=100.0, decay_rate=0.0, is_ephemeral=False), # Węzeł Długoterminowy (Nie znika)
        topology=Topology() # Koniec ścieżki
    )
    
    # 3. Zasilanie Grafu
    print("\n--- Pushing to Store ---")
    store.add_node(node_a)
    store.add_node(node_b)
    store.add_node(node_c)
    
    # 4. Odpalenie logiki Topologii (Brak if/else w kodzie głównym!)
    print("\n--- Starting Routing Execution ---")
    engine.execute_node(node_a.nodeId)
    
    # 5. Sprawdzenie systemu immunologicznego / Garbage Collectora
    print("\n--- Processing Entropy (Garbage Collection) ---")
    print(f"Nodes before decay: {list(store._nodes.keys())}")
    
    store.process_entropy()
    print(f"Nodes after 1st Clock Tick: {list(store._nodes.keys())}")
    
    store.process_entropy()
    print(f"Nodes after 2nd Clock Tick: {list(store._nodes.keys())}")


if __name__ == "__main__":
    run_test()
