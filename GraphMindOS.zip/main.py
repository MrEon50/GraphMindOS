import os
import urllib.request
import json
from copy import deepcopy
from core.intent.compiler import IntentCompiler
from core.storage.hybrid_store import HybridStore
from core.engine.router import RoutingEngine
from core.evolution.mutator import SandboxMutator
from core.engine.primitives import PrimitiveRegistry

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def fetch_local_models(endpoint: str = "http://localhost:11434/api/tags") -> list:
    """Odpytuje lokalną Ollamę i zwraca listę zainstalowanych modeli."""
    try:
        req = urllib.request.Request(endpoint, headers={'Accept': 'application/json'})
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
            return [m['name'] for m in result.get('models', [])]
    except Exception as e:
        print(f"[!] Błąd połączenia z Ollamą (Terminal Menu): {e}")
        # Domyślny zestaw fallback
        return ["qwen3.5:9b", "qwen2.5-coder:14b-instruct-q8_0", "llama3"]

def render_menu() -> str:
    clear_screen()
    print("==================================================")
    print("    GraphMindOS - Human-UI-Free AI-Native OS      ")
    print("    System Immunologiczny v1.0 Aktywny            ")
    print("==================================================\n")
    
    models = fetch_local_models()
    print("--- Dostępne Lokalne Modele Zmysłów (Ollama): ---")
    suggested_model = "qwen3.5:9b"
    suggested_idx = -1
    
    for idx, model in enumerate(models):
        if suggested_model in model:
            suggested_idx = idx + 1
            print(f"  [{idx + 1}] {model} [REKOMENDOWANY DO ZADAŃ]")
        else:
            print(f"  [{idx + 1}] {model}")
            
    print("\n--------------------------------------------------")
    wybor = input(f"Wybierz numer modelu {f'(Enter = {suggested_model})' if suggested_idx > 0 else '(Wpisz num)'}: ").strip()
    
    if not wybor and suggested_idx > 0:
        return models[suggested_idx - 1]
    
    try:
        idx = int(wybor)
        if 1 <= idx <= len(models):
            return models[idx - 1]
    except:
        pass
        
    # Bezpieczny fallback
    return models[0] if models else "qwen3.5:9b"


def main_loop():
    selected_model = render_menu()
    clear_screen()
    print(f"==================================================")
    print(f" Zalogowano: {selected_model}")
    print(f" Wpisz 'exit' by zamknąć system.")
    print(f"==================================================\n")
    
    # Bootowanie Systemu GraphOS
    compiler = IntentCompiler(model_name=selected_model)
    store = HybridStore()
    engine = RoutingEngine(store)
    mutator = SandboxMutator(model_name=selected_model)
    
    przykladowa_intencja = "Opcjonalna podpowiedź: 'Oblicz pensję dla 140h i stawki 75. Wyświetl to atomem calculate_salary.'"
    
    while True:
        print("-" * 50)
        # 1. Zmysły (Przyjmowanie intencji / Intent-Protocol API)
        intent = input(f"[Intencja]> ")
        if intent.lower() in ['exit', 'quit', 'q']:
            print("Zamykanie GraphMindOS...")
            break
            
        if not intent.strip():
            print(przykladowa_intencja)
            continue
            
        # 2. Kompilacja
        nodes = compiler.compile_intent(intent)
        if not nodes:
            print("  -> [BŁĄD] Kompilator zwrócił pusty strumień. Zmień intencję.")
            continue
            
        # Zapis do GraphDB
        start_node_id = None
        for node in nodes:
            store.add_node(node)
            if node.kind == "intent":
                start_node_id = node.nodeId
                
        if not start_node_id and len(nodes) > 0:
             start_node_id = nodes[0].nodeId # Fallback jak AI się pogubi
             
        # 3. Nawigacja Grafu
        print("\n--- Uruchomiono Egzkeutor (Topologia Mózgu) ---")
        engine.execute_node(start_node_id)
        
        # 4. MUTATOR SANDBOX (SELF-HEALING)
        failed_nodes = [n for n in store._nodes.values() if n.execution and n.execution.status == "failed"]
        for failed_node in failed_nodes:
            # Tworzymy fałszywy systemowy log błędu (Normalnie z parsera try/exceptu Atoma)
            error_message = (f"Atom 'calculate_salary' zgłosił błąd podczas odbierania argumentów z payload. " 
                             f"Klucze otrzymane to {list(failed_node.execution.payload.keys())}, brak 'hours'/'rate_per_hour'")
                             
            # Żądanie do AI, by wygenerowała łatkę bez naszej ingerencji !
            healed_node = mutator.heal_node(failed_node, error_msg=error_message)
            
            if healed_node and mutator.run_sandbox_judge(healed_node):
                print(f"[IMMUNE SYSTEM] Mutacja zatwierdzona! Restartowanie urwanego przewodu neurologicznego do węzła: {healed_node.nodeId}")
                # Aktualizacja bazy o naprawiony Payload w locie
                store.update_node(healed_node)
                # Dokończenie egzekucji tego urwanego procesu !
                engine.execute_node(healed_node.nodeId)
            else:
                print(f"[IMMUNE SYSTEM] Próba samo-naprawy zawiodła.")
                
        # 5. Sprzątanie (Entropy)
        print("\n--- Uruchomiono Entropy (Garbage Collector) ---")
        store.process_entropy()


if __name__ == "__main__":
    main_loop()
