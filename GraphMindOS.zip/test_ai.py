from core.intent.compiler import IntentCompiler
from core.storage.hybrid_store import HybridStore
from core.engine.router import RoutingEngine
from core.engine.primitives import PrimitiveRegistry
import time

# Rejestrujemy nowy atom pomocniczy przed testem 
@PrimitiveRegistry.register("calculate_salary")
def calculate_salary(payload: dict) -> dict:
    hours = payload.get("hours", 0)
    rate = payload.get("rate_per_hour", 0)
    salary = hours * rate
    print(f">> [PRIMITIVE PAYROLL]: Calculated Salary: {salary} <<")
    return {"result": salary}

def run_ai_test():
    print("=== GraphMindOS: AI Intent Compiler Test ===")
    
    # Inicjalizacja Głównego Mózgu
    store = HybridStore()
    engine = RoutingEngine(store)
    
    # Inicjalizacja Kompilatora (Tłumacza Osobistego podpiętego pod lokalny serwer Ollama)
    # Wykorzystujemy mocny, lokalny model usera dostępny na maszynie
    compiler = IntentCompiler(model_name="qwen2.5-coder:14b-instruct-q8_0")
    
    # 0. Nasza Intencja z zewnątrz
    intent_command = "Oblicz wynagrodzenie pracownika, który pracował 120 godzin przy stawce 50 złotych za godzinę. Zapisz wynik jako stan. Użyj atoma 'calculate_salary'."
    
    # 1. Kompilacja j. naturalnego -> struktura DAG 
    nodes = compiler.compile_intent(intent_command)
    
    if not nodes:
        print("[TEST] Błąd kompilacji intencji. Upewnij się, że serwer Ollama działa: \n  > ollama serve\n  > ollama run qwen2.5-coder:14b-instruct-q8_0")
        return
        
    print(f"\n--- Storing {len(nodes)} compiled AI nodes ---")
    start_node_id = None
    
    # Odnalezienie węzła startowego i wgranie całości do bazy
    for i, node in enumerate(nodes):
        store.add_node(node)
        
        if node.kind == "intent":
             start_node_id = node.nodeId
    
    if not start_node_id:
        print("[TEST] AI nie zdefiniowało węzła startowego typu 'intent'!")
        return
        
    # 2. Silnik grafu puszczony samopas (Egzekucja)
    print("\n--- Starting Routing Execution ---")
    engine.execute_node(start_node_id)
    
    # 3. Widok z Pamięci
    print("\n--- Pamięć Grafu Przed GC ---")
    for n_id, n in store._nodes.items():
         print(f"  + {n_id} (kind: {n.kind}) | Zmienne (stan): {n.execution.payload if n.execution else {}}")
         
    store.process_entropy()
    
    print("\n--- Pamięć Grafu Po 1szym usunięciu śmieci ---")
    for n_id, n in store._nodes.items():
         print(f"  + {n_id} (kind: {n.kind})")


if __name__ == "__main__":
    run_ai_test()
