from core.engine.primitives import PrimitiveRegistry

@PrimitiveRegistry.register("text_cleaner", "Narzedzie do czyszczenia tekstu.")
def text_cleaner(payload: dict) -> dict:
    try:
        text = payload.get("text")
        
        if not isinstance(text, str):
            raise ValueError("Brak lub niepoprawny typ klucza 'text' w payloadie")
            
        # Zamiana na małe litery
        processed_text = text.lower()
        
        # Usuwanie znaków specjalnych (zachowuje liter alfabetu i cyfry oraz spacje)
        cleaned_chars = [char for char in processed_text if char.isalnum() or char.isspace()]
        clean_string = "".join(cleaned_chars)
        
        # Normalizacja spacj - usuwanie wielokrotnych odstepów
        clean_string = " ".join(clean_string.split())
        
        return {"cleaned_text": clean_string}
    except ValueError:
        return {"error": "Nieprawidłowe dane wejściowe"}