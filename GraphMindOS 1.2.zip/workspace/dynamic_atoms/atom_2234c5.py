from core.engine.primitives import PrimitiveRegistry
import subprocess

@PrimitiveRegistry.register("cmd_executor", "Uruchamia polecenia systemowe.")
def cmd_executor(payload: dict) -> dict:
    try:
        command = payload.get("command")
        if not command:
            raise ValueError("Brak kluczowej komendy 'command' w payloadu.")
        
        result = subprocess.run(
            command, 
            shell=True, 
            capture_output=True, 
            text=True, 
            encoding="utf-8"
        )
        
        full_output = ""
        if result.stdout:
            full_output += result.stdout.strip()
        if result.stderr:
            full_output += "\n\n" + result.stderr.strip()
            
        payload["console_output"] = full_output
        
    except subprocess.CalledProcessError as e:
        raise ValueError(f"Błąd wykonania polecenia z kodem {e.returncode}.")
    except Exception as e:
        raise ValueError(f"Wystąpił nieznany błąd: {str(e)}")

    return payload