from core.engine.primitives import PrimitiveRegistry

@PrimitiveRegistry.register("write_file", "Narzędzie do zapisywania plików tekstowych.")
def write_file(payload: dict) -> dict:
    try:
        filepath = payload.get("filepath")
        content = payload.get("content", "")
        mode = payload.get("mode", "w")

        if not isinstance(filepath, str):
            raise ValueError("Błąd: filepath musi być stringiem.")

        if content is None or len(content) == 0:
            raise ValueError("Brak parametr content lub jest pusty.")

        valid_modes = {"r", "w", "a", "x"}
        if mode and mode not in valid_modes:
             raise ValueError(f"Błąd: nieprawidłowy tryb pliku '{mode}'.")

        with open(filepath, mode) as f:
            f.write(content)

        return {"status": "success", "message": "Plik zapisany pomyślnie."}
    
    except ValueError:
        return {"status": "error", "message": "Niepoprawne dane wejściowe (ValueError)."}
    except Exception as e:
        return {"status": "error", "message": f"Błąd systemu: {str(e)}"}