from core.engine.primitives import PrimitiveRegistry
import os
import shutil

@PrimitiveRegistry.register("file_sorter", "Sortuje pliki w folderze wg ich rozszerzenia.")
def file_sorter(payload: dict) -> dict:
    try:
        target_folder = payload.get("target_folder")
        
        if not target_folder:
            raise ValueError("Brak klucza 'target_folder' w parametrach wejściowych.")
        
        # Walidacja ścieżki folderu
        if not os.path.isdir(target_folder):
            raise ValueError(f"Ścieżka '{target_folder}' nie istnieje.")
            
        items = os.listdir(target_folder)
        
        for item in items:
            filepath = os.path.join(target_folder, item)
            
            # Pomijamy podfoldery (subfolders), tylko pliki
            if os.path.isdir(filepath):
                continue
            
            _, ext = os.path.splitext(item)
            extension_name = ext or "bez_rozszerzenia"
            target_dir = os.path.join(target_folder, extension_name)
            
            # Utwórz katalog na rozszerzenie jeśli go nie ma
            os.makedirs(target_dir, exist_ok=True)
            
            # Przenieś plik do odpowiedniego folderu
            shutil.move(filepath, target_dir)
        
        return {"status": "success", "message": "Pliki posortowano."}
        
    except ValueError:
        return {"status": "error", "message": "Wystąpił błąd wartości w walidacji danych."}