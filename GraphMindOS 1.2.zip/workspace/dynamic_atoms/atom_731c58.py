from core.engine.primitives import PrimitiveRegistry
import shutil
import os

@PrimitiveRegistry.register("zip_archiver", "Pakuje wskazany folder do archiwum zip.")
def zip_archiver(payload: dict) -> dict:
    try:
        source_folder = payload.get("source_folder")
        output_path = payload.get("output_path")

        if not source_folder or not output_path:
            raise ValueError("Brak podanych kluczy 'source_folder' lub 'output_path' w payload.")
        
        if not os.path.isdir(source_folder):
            raise ValueError("Folder źródłowy nie istnieje.")

        # Usunięcie ewentualnego rozszerzenia .zip aby uniknąć podwójnych rozszerzeń przy użyciu make_archive
        safe_name = output_path.rsplit(".zip", 1)[0] if output_path.endswith(".zip") else output_path
        
        archive_file = shutil.make_archive(safe_name, 'zip', source_folder)
        
        return {
            "status": "success",
            "output": archive_file,
            "message": "Pakowanie zakończone powodzeniem."
        }
    except ValueError:
        return {
            "status": "error",
            "message": "Wystąpił błąd danych wejściowych."
        }