from core.storage.hybrid_store import HybridStore
from core.engine.router import RoutingEngine
from core.models.node import GraphNode, Topology, Relationship, Execution, Entropy
from core.engine.primitives import PrimitiveRegistry
import os

# 1. Setup
store = HybridStore()
engine = RoutingEngine(store)

# 2. Tworzymy węzeł A: read_directory
node_a = GraphNode(
    nodeId="node_a",
    kind="primitive",
    execution=Execution(
        processor_ref="read_directory",
        payload={"path": "workspace"}
    ),
    topology=Topology(
        outputs=[Relationship(targetId="node_b", relationshipType="next", weight=1.0)]
    )
)

# 3. Tworzymy węzeł B: log_message
# Zauważ, że payload jest PUSTY. Powinien zostać wypełniony przez node_a.
node_b = GraphNode(
    nodeId="node_b",
    kind="primitive",
    execution=Execution(
        processor_ref="log_message",
        payload={} 
    )
)

store.add_node(node_a)
store.add_node(node_b)

print("\n--- TEST: PAYLOAD FORWARDING (BUG-2) ---")
engine.execute_node("node_a")

# Sprawdzamy czy node_b dostał dane
final_node_b = store.get_node("node_b")
print(f"\nNode B Final Payload: {final_node_b.execution.payload}")

if "files" in final_node_b.execution.payload:
    print("\nSUCCESS: Payload forwarded successfully!")
else:
    print("\nFAILED: Payload NOT forwarded.")

# 4. TEST: PRE-PROCESSOR (BUG-4)
from core.intent.preprocessor import IntentPreProcessor
print("\n--- TEST: INTENT PRE-PROCESSOR (BUG-4) ---")
pre = IntentPreProcessor(model_name="qwen3.5:9b")
result = pre.process("Zrób porządek z moimi plikami na pulpicie")
print(f"Original: 'Zrób porządek z moimi plikami na pulpicie'")
print(f"Processed: '{result}'")

if "Odczytaj" in result or "Pulpit" in result or "pliki" in result:
    print("\nSUCCESS: Intent pre-processed successfully!")
else:
    print("\nWARNING: Pre-processor returned raw result or unexpected format.")
