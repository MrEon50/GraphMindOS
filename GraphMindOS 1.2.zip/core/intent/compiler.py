import json
import urllib.request
import urllib.error
import socket
from typing import List, Dict, Any
from core.models.node import GraphNode, Topology, Relationship, Execution, Entropy
from core.engine.primitives import PrimitiveRegistry

class IntentCompiler:
    """
    Kompilator Intencji. Łączy się z lokalnym modelem Ollama, 
    aby przetłumaczyć język naturalny na sub-graf (DAG) zgodny z GraphMindOS.
    """
    
    def __init__(self, model_name: str = "qwen2.5-coder:14b-instruct-q8_0", endpoint: str = "http://localhost:11434/api/chat"):
        self.model_name = model_name
        self.endpoint = endpoint
        
        # System prompt wymuszający ścisłą strukturę wyjściową.
        self.system_prompt = """
Jesteś Głównym Kompilatorem Intencji (Intent Compiler) w systemie GraphMindOS.
Twoim zadaniem jest zamiana żądania użytkownika (język naturalny) w graf akcji (Topologię) ustandaryzowaną jako JSON.

Założenia GraphMindOS:
- Graf składa się z węzłów. Każdy węzeł ma 'nodeId'.
- Węzły mogą być 3 rodzajów (kind):
  1. 'intent' (punkt wejścia z żądania)
  2. 'primitive' (Atom wykonawczy, np. ma wpisane execution.processor_ref = 'math_add', 'log_message', etc.)
  3. 'state' (Przechowuje twardy wynik logiki)
- 'processor_ref': Dobierz intuicyjnie do zadania. Jeśli system nie posiada odpowiedniego narzędzia (np. 'sort_files'), MOŻESZ wymyślić nową nazwę. System spróbuje ją automatycznie wygenerować (Self-Evolution).
- UŻYWANIE ATOMÓW: Narzędzia w 'processor_ref' mogą być już w systemie LUB wymyślone przez Ciebie ad-hoc. W payloadzie domyśl się argumentów. Dla brakujących atomów oznacz je prefixem 'atom_'.
- KRYTYCZNA ZASADA BEZPIECZEŃSTWA: Jeżeli Twoja intencja wymaga węzła modyfikującego lokalne pliki LUB WYSYŁAJĄCEGO DANE w otwartą sieć poprzez POST ('http_post'), MUSISZ poprzedzić ten przekaźnik węzłem z `processor_ref: "ask_user_permission"` i przepuścić w jego 'outputs' przepływ TYLKO pod warunkiem `condition: "permission_granted == True"`.
- Wewnątrz 'ask_user_permission' w payload obowiązkowo dodaj klucz 'consequences', by krótko i dobitnie wyjaśnić, co grozi przy tej operacji.
- RAG i ODCZYT: Jeśli logujesz wiedzę, w payloadzie węzła 'state' dopisz np. {"text_content": "..."} aby baza RAG poprawnie ją zaindeksowała.
- 'entropy': 'lifespan' (1.0 domyślnie), 'decay_rate' (0.5 domyślnie), 'is_ephemeral' (true dla tymczasowych).

MUSISZ ZWRÓCIĆ **TYLKO** CZYSTY JSON w poniższym schemacie. 
PAMIĘTAJ: ZAWSZE zwróć CAŁY słownik z kluczem `"nodes"`, w którym znajdzie się pełna TABLICA (LISTA JSON `[...]`) WSZYSTKICH wygenerowanych węzłów. Przeanalizuj i generuj wszystkie potrzebne węzły zanim zamkniesz JSON.
Schemat Wyjściowy (Output JSON Schema):
{
  "nodes": [
    {
      "nodeId": "string (unikalne)",
      "kind": "intent, primitive, lub state",
      "execution": {
        "processor_ref": "nazwa opcjonalnego atomu (dla primitive)",
        "payload": {}
      },
      "topology": {
        "outputs": [
          {"targetId": "string", "relationshipType": "string", "weight": float, "condition": "string"}
        ]
      },
      "entropy": {
        "lifespan": float,
        "decay_rate": float,
        "is_ephemeral": boolean
      }
    }
  ]
}
"""

    def compile_intent(self, user_intent: str) -> List[GraphNode]:
        # --- DYNAMICZNIE ŁADUJ DOSTĘPNE NARZĘDZIA I ICH OPISY DO PROMPTU ---
        tools_desc = []
        for name, desc in PrimitiveRegistry._descriptions.items():
            tools_desc.append(f"- '{name}': {desc}")
        
        atoms_str = "\n".join(tools_desc)
        
        dynamic_system_prompt = self.system_prompt + f"\n\nAKTUALNIE DOSTĘPNE NARZĘDZIA (ATOMY), KTÓRE MOŻESZ WYKORZYSTAĆ:\n{atoms_str}"
        
        print(f"[COMPILER] Translating Intent via Ollama ({self.model_name}): '{user_intent}'")
        
        payload = {
            "model": self.model_name,
            "messages": [
                {"role": "system", "content": dynamic_system_prompt},
                {"role": "user", "content": f"Skompiluj proszę tę intencję: {user_intent}"}
            ],
            "stream": False
        }
        
        try:
            req = urllib.request.Request(
                self.endpoint, 
                data=json.dumps(payload).encode('utf-8'),
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req, timeout=90) as response:
                result = json.loads(response.read().decode('utf-8'))
                
            import re
            
            raw_content = result.get("message", {}).get("content", "")
            
            # Wzmocnione, niezawodne usuwanie znaczników, które psuły parser JSON i odrzucały kompilację
            match = re.search(r'```(?:json)?\s*(.*?)\s*```', raw_content, re.DOTALL)
            if match:
                raw_content = match.group(1).strip()
            else:
                raw_content = raw_content.strip()
                
            try:
                data = json.loads(raw_content)
            except json.JSONDecodeError as decode_err:
                print(f"[COMPILER] Otrzymano nieczysty obiekt JSON od modelu: {decode_err}")
                return []
                
            # Upewnijmy się, że zawsze wyciągamy listę układów
            if isinstance(data, list):
                nodes_list = data
            elif isinstance(data, dict):
                # Szukamy klucza oznaczającego listę węzłów
                if "nodes" in data:
                    nodes_list = data["nodes"]
                elif "nodeId" in data:
                    nodes_list = [data] # LLM zduplikował jako pojedynczy element
                else:
                    # Model mógł nazwać korzeń inaczej
                    for key, val in data.items():
                        if isinstance(val, list) and len(val) > 0 and isinstance(val[0], dict) and "nodeId" in val[0]:
                            nodes_list = val
                            break
                    else:
                        print(f"[COMPILER ALERT] Model zwrócił poprawny JSON, ale bez ustrukturyzowanych węzłów! Treść: {data}")
                        nodes_list = []
            else:
                nodes_list = []
                
            # Ekstrakcja do modeli GraphNode (Pydantic zrobi walidację)
            nodes = []
            for node_data in nodes_list:
                # Budowanie złożonych obiektów ręcznie z dict
                execution_data = node_data.get("execution", {})
                exc = Execution(
                    processor_ref=execution_data.get("processor_ref"),
                    payload=execution_data.get("payload", {})
                )
                
                topo_data = node_data.get("topology", {})
                outputs = []
                for out_data in topo_data.get("outputs", []):
                    outputs.append(Relationship(**out_data))
                topo = Topology(outputs=outputs)
                
                ent_data = node_data.get("entropy", {})
                ent = Entropy(**ent_data)
                
                node = GraphNode(
                    nodeId=node_data.get("nodeId"),
                    kind=node_data.get("kind"),
                    execution=exc,
                    topology=topo,
                    entropy=ent
                )
                nodes.append(node)
                
            print(f"[COMPILER] Successfully compiled {len(nodes)} nodes.")
            return nodes
            
        except socket.timeout:
            print(f"[COMPILER] Ollama (LLM) myśli zbyt długo (Timeout > 90s). Przerwanie kompilacji.")
            return []
        except urllib.error.URLError as e:
            print(f"[COMPILER] Nie można połączyć się z Ollama: {e}. Upewnij się, że lokalny serwer działa na porcie 11434.")
            return []
        except Exception as e:
            print(f"[COMPILER] Błąd parsowania wyjścia LLM: {e}")
            return []
