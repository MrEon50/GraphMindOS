import json
import urllib.request
import socket

class IntentPreProcessor:
    """
    Warstwa tłumaczenia potocznego języka na precyzyjny cel techniczny (BUG-4).
    Przekłada prośby typu "Zrób porządek" na instrukcje dla kompilatora DAG.
    """
    def __init__(self, model_name: str = "qwen3.5:9b", endpoint: str = "http://localhost:11434/api/chat"):
        self.model_name = model_name
        self.endpoint = endpoint
        self.system_prompt = """
Jesteś Ekspertem Analizy Intencji w systemie GraphMindOS.
Twoim zdaniem jest przeformułowanie potocznej, niejasnej prośby użytkownika na precyzyjny, 
techniczny plan działania, który zostanie zrozumiany przez kompilator grafów akcji.

Zasady:
1. Jeśli użytkownik pisze konkretnie (np. "Oblicz 2+2"), zwróć ten tekst bez zmian.
2. Jeśli użytkownik pisze potocznie (np. "Zrób porządek"), przeanalizuj co to może oznaczać w kontekście systemu plików.
3. Zwróć krótki, precyzyjny opis krok po kroku.
4. NIE generuj JSONa. Zwróć tylko surowy tekst instrukcji.

Przykład:
Użytkownik: "Posprzątaj mój pulpit"
Wynik: "Odczytaj zawartość folderu Desktop. Pogrupuj pliki według rozszerzeń. Przenieś pliki graficzne do folderu Obrazy, a dokumenty do folderu Dokumenty."
"""

    def process(self, raw_intent: str) -> str:
        payload = {
            "model": self.model_name,
            "messages": [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": f"Przeformułuj tę intencję: {raw_intent}"}
            ],
            "stream": False
        }
        
        try:
            print(f"[PRE-PROCESSOR] Interpretowanie potocznego języka...")
            req = urllib.request.Request(
                self.endpoint,
                data=json.dumps(payload).encode('utf-8'),
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode('utf-8'))
                processed = result.get("message", {}).get("content", "").strip()
                print(f"[PRE-PROCESSOR] Przetłumaczono na: '{processed[:100]}...'")
                return processed
        except Exception:
            # Fallback - jeśli pre-processor zawiedzie, zwracamy oryginał
            return raw_intent
