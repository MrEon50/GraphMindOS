import os
import urllib.request
import json
from copy import deepcopy
from typing import List, Dict, Any
from core.intent.compiler import IntentCompiler
from core.intent.preprocessor import IntentPreProcessor
from core.storage.hybrid_store import HybridStore
from core.engine.router import RoutingEngine
from core.evolution.mutator import SandboxMutator
from core.evolution.tool_designer import ToolDesigner
from core.engine.primitives import PrimitiveRegistry

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def fetch_local_models(endpoint: str = "http://localhost:11434/api/tags") -> list:
    """Odpytuje lokalną Ollamę i zwraca listę zainstalowanych modeli."""
    try:
        req = urllib.request.Request(endpoint, headers={'Accept': 'application/json'})
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
            return [m['name'] for m in result.get('models', [])]
    except Exception as e:
        print(f"[!] Błąd połączenia z Ollamą (Terminal Menu): {e}")
        # Domyślny zestaw fallback
        return ["qwen3.5:9b", "qwen2.5-coder:14b-instruct-q8_0", "llama3"]

def render_menu() -> str:
    clear_screen()
    print("==================================================")
    print("    GraphMindOS - Human-UI-Free AI-Native OS      ")
    print("    System Immunologiczny v1.0 Aktywny            ")
    print("==================================================\n")
    
    models = fetch_local_models()
    print("--- Dostępne Lokalne Modele Zmysłów (Ollama): ---")
    suggested_model = "qwen3.5:9b"
    suggested_idx = -1
    
    for idx, model in enumerate(models):
        if suggested_model in model:
            suggested_idx = idx + 1
            print(f"  [{idx + 1}] {model} [REKOMENDOWANY DO ZADAŃ]")
        else:
            print(f"  [{idx + 1}] {model}")
            
    print("\n--------------------------------------------------")
    wybor = input(f"Wybierz numer modelu {f'(Enter = {suggested_model})' if suggested_idx > 0 else '(Wpisz num)'}: ").strip()
    
    if not wybor and suggested_idx > 0:
        return models[suggested_idx - 1]
    
    try:
        idx = int(wybor)
        if 1 <= idx <= len(models):
            return models[idx - 1]
    except:
        pass
        
    # Bezpieczny fallback
    return models[0] if models else "qwen3.5:9b"


def main_loop():
    selected_model = render_menu()
    clear_screen()
    print(f"==================================================")
    print(f" Zalogowano: {selected_model}")
    print(f" Wpisz 'exit' by zamknąć system.")
    print(f"==================================================\n")
    
    # Bootowanie Systemu GraphOS
    preprocessor = IntentPreProcessor(model_name=selected_model)
    compiler = IntentCompiler(model_name=selected_model)
    store = HybridStore()
    engine = RoutingEngine(store)
    mutator = SandboxMutator(model_name=selected_model)
    
    # Opcjonalne ładowanie na starcie
    PrimitiveRegistry.load_dynamic_atoms()
    
    przykladowa_intencja = "Opcjonalna podpowiedź: 'Oblicz pensję dla 140h i stawki 75' LUB 'Stwórz atom który zapisuje tekst do pliku txt'"
    
    while True:
        print("-" * 50)
        # 1. Zmysły (Przyjmowanie intencji / Intent-Protocol API)
        intent = input(f"[Intencja]> ")
        
        # --- OBSŁUGA KOMEND SYSTEMOWYCH (SLASH COMMANDS) ---
        if intent.strip().startswith("/"):
            cmd = intent.strip().split(" ", 1)[0].lower()
            args = intent.strip()[len(cmd):].strip()
            
            if cmd in ["/exit", "/quit"]:
                print("Zamykanie GraphMindOS...")
                break
                
            elif cmd == "/help":
                print("\n[DOSTEPNE KOMENDY SYSTEMOWE]")
                print("  /help          - Wyswietla te liste komend.")
                print("  /info          - Informacje o GraphMindOS i instrukcja obslugi.")
                print("  /tools         - Pokazuje liste dostepnych narzedzi (Atomow) z opisami.")
                print("  /del <nazwa>   - Usuwa dynamiczne narzedzie z systemu (nie mozna usunac [CORE]).")
                print("  /model <tekst> - Zadaj bezposrednie pytanie do modelu AI (bez budowania grafu).")
                print("  /clear         - Czysci ekran konsoli.")
                print("  /exit          - Zamyka system.")
                continue
                
            elif cmd == "/info":
                print("\n[O SYSTEMIE GraphMindOS]")
                print("GraphMindOS to AI-Native Operating System.")
                print("Zamiast wykonywać sztywny kod, system słucha Twoich Intencji w języku naturalnym,")
                print("tłumaczy je na plan działania i w locie kompiluje Dynamiczny Graf Akcji (DAG).")
                print("Narzędzia dynamiczne znajdują się w folderze dynamic_atoms")
                print("\nJak korzystać?")
                print("1. Wpisz potoczną prośbę, np. 'Znajdź pliki txt w moim folderze'.")
                print("2. Jeśli chcesz wymusić użycie narzędzia, wpisz: 'Użyj <nazwa_narzędzia> do...'")
                print("3. Jeśli systemowi brakuje narzędzia, poproś by je napisał: 'Stwórz narzędzie, które...'")
                continue
                
            elif cmd in ["/tools", "/tool"]:
                print("\n[ZAINSTALOWANE NARZEDZIA / ATOMY]")
                if not PrimitiveRegistry._registry:
                    print("  Brak zaladowanych narzedzi.")
                else:
                    core_count = 0
                    dynamic_count = 0
                    for name, func in PrimitiveRegistry._registry.items():
                        desc = PrimitiveRegistry._descriptions.get(name, "Brak opisu.")
                        origin = PrimitiveRegistry._origins.get(name, "CORE")
                        tag = "[CORE]" if origin == "CORE" else "[DYNAMIC]"
                        print(f"  - {name} {tag}: {desc}")
                        if origin == "CORE":
                            core_count += 1
                        else:
                            dynamic_count += 1
                    print(f"\n  Podsumowanie: {core_count} wbudowanych, {dynamic_count} dynamicznych ({core_count + dynamic_count} lacznie)")
                print("\nWskazowka: Mozesz zasugerowac uzycie narzedzia w Intencji, np. 'Uzyj read_directory'.")
                continue
                
            elif cmd == "/clear":
                clear_screen()
                continue
                
            elif cmd == "/model":
                if not args:
                    print("[!] Podaj treść zapytania, np. /model Jak działa silnik spalinowy?")
                else:
                    print(f"\n[MODEL {selected_model} MYŚLI...]")
                    try:
                        req_data = json.dumps({
                            "model": selected_model,
                            "messages": [{"role": "user", "content": args}],
                            "stream": False
                        }).encode('utf-8')
                        req = urllib.request.Request("http://localhost:11434/api/chat", data=req_data, headers={'Content-Type': 'application/json'})
                        with urllib.request.urlopen(req, timeout=120) as response:
                            res_json = json.loads(response.read().decode('utf-8'))
                            print("\n" + res_json.get("message", {}).get("content", "").strip())
                    except Exception as e:
                        print(f"[!] Błąd komunikacji z modelem: {e}")
                continue
            elif cmd == "/del":
                if not args:
                    print("[!] Podaj nazwe narzedzia do usuniecia, np. /del text_cleaner")
                else:
                    tool_name = args.strip()
                    confirm = input(f"Czy na pewno chcesz usunac narzedzie '{tool_name}'? [Y/N]: ").strip().lower()
                    if confirm in ['y', 'yes']:
                        result = PrimitiveRegistry.unregister(tool_name)
                        if result["success"]:
                            deleted = result.get('deleted_file', 'nieznany')
                            print(f"[UNINSTALL] Atom '{tool_name}' zostal usuniety z rejestru.")
                            if deleted:
                                print(f"[UNINSTALL] Plik zrodlowy '{deleted}' zostal skasowany z dynamic_atoms/.")
                            else:
                                print(f"[UNINSTALL] Nie znaleziono pliku zrodlowego (atom byl tylko w pamieci).")
                        else:
                            print(f"[!] {result['reason']}")
                    else:
                        print("[!] Anulowano usuwanie.")
                continue

            else:
                print(f"[!] Nieznana komenda: {cmd}. Wpisz /help aby zobaczyc liste.")
                continue

        if not intent.strip():
            print("Wpisz /help aby zobaczyć dostępne komendy.")
            continue
            
        try:
            # 1b. The Tool Designer (Self-Evolving Code Pipeline)
            # Inteligentna detekcja na bazie slow kluczowych (zamiast sztywnych prefixow)
            intent_lower = intent.lower()
            creation_verbs = ["stwórz", "stworz", "zbuduj", "napisz", "zaprojektuj", "zrób", "zrob", "dodaj", "wygeneruj"]
            tool_nouns = ["atom", "narzędzie", "narzedzie", "tool", "zmysł", "zmysl", "narząd", "narzad"]
            has_verb = any(v in intent_lower for v in creation_verbs)
            has_noun = any(n in intent_lower for n in tool_nouns)
            is_tool_request = has_verb and has_noun
            
            if is_tool_request:
                designer = ToolDesigner(model_name=selected_model)
                new_code = designer.design_tool(intent)
                
                if new_code and designer.validate_code(new_code):
                    print(f"\n==================================================")
                    print(f"[KLAUZULA EWOLUCYJNA] Agent stworzyl nowy narzad:")
                    print(f"==================================================\n")
                    print(new_code)
                    print(f"\n==================================================")
                    choice = input("> Czy zgadzasz się, aby skompilować ten kod i wstrzyknąć w rdzeń OS? [Y/N]: ").strip().lower()
                    if choice in ['y', 'yes']:
                        # Zapis pliku
                        dynamic_dir = os.path.abspath(os.path.join(os.getcwd(), "workspace", "dynamic_atoms"))
                        import uuid
                        safe_filename = f"atom_{uuid.uuid4().hex[:6]}.py"
                        file_path = os.path.join(dynamic_dir, safe_filename)
                        if not os.path.exists(dynamic_dir):
                            os.makedirs(dynamic_dir)
                        with open(file_path, "w", encoding="utf-8") as raw_f:
                            raw_f.write(new_code)
                            
                        # Hot-Reload w pamięć RAM
                        PrimitiveRegistry.load_dynamic_atoms()
                        print(f"[SUCCESS] Nowy zmysl pomyslnie zintegrowany. Mozesz go uzywac w Intencjach, podajac jego nowa nazwe!")
                    else:
                        print(f"[REJECTED] Odmowiono wstrzykniecia. Kod zniszczony.")
                else:
                    print(f"[ERROR] Agent zawiodl podczas pisania Atoma lub Judge go zablokowal.")
                continue # Wróć po zbudowaniu atoma na początek menu
                
            # 2. Pre-processing (Tłumaczenie potocznego języka na techniczne polecenia BUG-4)
            processed_intent = preprocessor.process(intent)
            
            # 3. Kompilacja
            nodes = compiler.compile_intent(processed_intent)
            if not nodes:
                print("  -> [BŁĄD] Kompilator zwrócił pusty strumień. Zmień intencję.")
                continue

            # 3b. AUTO-EVOLUTION (Wykrywanie brakujących atomów - UPG-2)
            for node in nodes:
                if node.kind == "primitive" and node.execution.processor_ref:
                    if node.execution.processor_ref not in PrimitiveRegistry._registry:
                        print(f"\n[AUTO-EVOLUTION] Wykryto brakujący Atom: '{node.execution.processor_ref}'")
                        print(f"[AUTO-EVOLUTION] Uruchamiam proces projektowania brakującego narządu...")
                        
                        designer = ToolDesigner(model_name=selected_model)
                        # Tworzymy opis na podstawie kontekstu węzła
                        desc = f"Stwórz atom o nazwie '{node.execution.processor_ref}', który w payload przyjmuje argumenty: {list(node.execution.payload.keys())}"
                        new_code = designer.design_tool(desc)
                        
                        if new_code and designer.validate_code(new_code):
                            print(f"\n==================================================")
                            print(f"[KLAUZULA EWOLUCYJNA] Wygenerowano brakujący kod:")
                            print(f"==================================================\n")
                            print(new_code)
                            choice = input(f"> Czy chcesz zainstalować ten brakujący Atom '{node.execution.processor_ref}'? [Y/N]: ").strip().lower()
                            if choice in ['y', 'yes']:
                                dynamic_dir = os.path.abspath(os.path.join(os.getcwd(), "workspace", "dynamic_atoms"))
                                if not os.path.exists(dynamic_dir): os.makedirs(dynamic_dir)
                                import uuid
                                with open(os.path.join(dynamic_dir, f"auto_{node.execution.processor_ref}_{uuid.uuid4().hex[:4]}.py"), "w", encoding="utf-8") as f:
                                    f.write(new_code)
                                PrimitiveRegistry.load_dynamic_atoms()
                            else:
                                print("[!] Zrezygnowano. Egzekucja grafu może się nie udać.")
            
            # 4. Zapis do GraphDB
            start_node_id = None
            for node in nodes:
                store.add_node(node)
                if node.kind == "intent":
                    start_node_id = node.nodeId
                    
            if not start_node_id and len(nodes) > 0:
                 start_node_id = nodes[0].nodeId # Fallback jak AI się pogubi
                 
            # 3. Nawigacja Grafu
            print("\n--- Uruchomiono Egzkeutor (Topologia Mózgu) ---")
            engine.execute_node(start_node_id)
            
            # 4. MUTATOR SANDBOX (SELF-HEALING)
            failed_nodes = [n for n in store._nodes.values() if n.execution and n.execution.status == "failed"]
            for failed_node in failed_nodes:
                # Pobieramy prawdziwy log błędu z węzła (BUG-3 FIX)
                error_message = failed_node.execution.error or "Nieznany błąd wykonania Atomu."
                                 
                # Żądanie do AI, by wygenerowała łatkę bez naszej ingerencji !
                healed_node = mutator.heal_node(failed_node, error_msg=error_message)
                
                if healed_node and mutator.run_sandbox_judge(healed_node):
                    print(f"[IMMUNE SYSTEM] Mutacja zatwierdzona! Restartowanie urwanego przewodu neurologicznego do węzła: {healed_node.nodeId}")
                    # Aktualizacja bazy o naprawiony Payload w locie
                    store.update_node(healed_node)
                    # Dokończenie egzekucji tego urwanego procesu !
                    engine.execute_node(healed_node.nodeId)
                else:
                    print(f"[IMMUNE SYSTEM] Próba samo-naprawy zawiodła.")
                    
            # 5. Sprzątanie (Entropy)
            print("\n--- Uruchomiono Entropy (Garbage Collector) ---")
            store.process_entropy()

        except KeyboardInterrupt:
            print("\n[PANIC BUTTON] Wymuszono twarde zatrzymanie procesu (Ctrl+C).")
            print("[PANIC BUTTON] GraphMindOS wraca do menu Intencji...")
            continue
        except Exception as system_exc:
            print(f"\n[KRYTYCZNY BLAD SYSTEMU]: {system_exc}")

if __name__ == "__main__":
    main_loop()
